<?php
/*
Template Name: Contact
*/

get_header(); ?>

<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>

<!-- Title Inro -->
<?php get_template_part( 'templates/page', 'title-intro' ); ?>

<!-- Contact Us Form -->
<?php get_template_part( 'templates/page', 'contact-us-form' ); ?>

<!-- Contact Us Block -->
<div class="pb-150">
<?php get_template_part( 'parts/loop', 'contact-us-block' ); ?>
</div>


<?php get_footer(); ?>

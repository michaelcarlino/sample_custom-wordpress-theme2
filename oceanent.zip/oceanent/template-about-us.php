<?php
/*
Template Name: About Us
*/

get_header(); ?>

<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>

<!-- Page About Us Title Intro -->
<?php get_template_part( 'templates/page', 'about-us-title-intro' ); ?>

<!-- Meet the Physicians Title Intro -->
<?php get_template_part( 'parts/loop', 'meet-the-physicians' ); ?>

<!-- Testimonials -->
<?php get_template_part( 'parts/loop', 'testimonials' ); ?>


<?php get_footer(); ?>

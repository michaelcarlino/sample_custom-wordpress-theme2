<?php
/*
Template Name: Patient Education
*/

get_header(); ?>

<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>

<!-- Title Inro -->
  <div id="patient-education" class="grid-x ptb-100">
    	<div class="cell large-12 text-center"><h1 class="title">Patient Education</h1></div><br>
      <div class="cell large-12 text-center the_content-large"><p>Please explore our library of topics to stay well-informed on ENT disorders and diseases.</p>
	  </div>
  </div>	
</div>


<!-- Search Function -->
<div class="grid-container">
  <div class="grid-x">
    <div class="cell large-12">
    	<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
    <div><label class="screen-reader-text" for="s"></label>
        <input type="text" value="" name="s" id="s" />
        <input class="button" type="submit" id="searchsubmit" value="Search" />
    </div>
</form>
    </div>
  </div>
</div>


<!-- Patient Education Links Block -->
<div class="pb-50">
<?php get_template_part( 'parts/loop', 'education-links' ); ?>
</div>


<?php get_footer(); ?>

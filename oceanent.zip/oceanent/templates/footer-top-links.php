
<!-- Footer Top Links -->

<?php
$footer_top_link_1 = get_field('footer_top_link_1', 'option');
$footer_top_link_2 = get_field('footer_top_link_2', 'option'); 
$footer_top_link_3 = get_field('footer_top_link_3', 'option');
$footer_top_link_1_url = get_field('footer_top_link_1_url', 'option');
$footer_top_link_2_url = get_field('footer_top_link_2_url', 'option'); 
$footer_top_link_3_url = get_field('footer_top_link_3_url', 'option');
?>
					
	<div class="grid-container">
		<div class="grid-x text-center">
			<div class="cell large-4"><a href="<?php echo $footer_top_link_1_url; ?>"><h3 class="footer-top-links"><?php echo $footer_top_link_1; ?></h3></a><hr class="lightblue-line"></div>
					    
			<div class="cell large-4"><a href="<?php echo $footer_top_link_2_url; ?>"><h3 class="footer-top-links"><?php echo $footer_top_link_2; ?></h3></a><hr class="lightblue-line"></div>
					    
			<div class="cell large-4"><a href="<?php echo $footer_top_link_3_url; ?>" target="_blank"><h3 class="footer-top-links"><?php echo $footer_top_link_3; ?></h3></a><hr class="lightblue-line"></div>
		</div>
	</div>
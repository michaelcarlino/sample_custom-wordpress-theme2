
<!-- Columns 2 -->

<?php
$columns_2_title_1 = get_field('columns_2_title_1');
$columns_2_text_1 = get_field('columns_2_text_1'); 
$columns_2_title_2 = get_field('columns_2_title_2');
$columns_2_text_2 = get_field('columns_2_text_2');
?>
					
	<div class="grid-container ptb-100">
		<div class="grid-x">
			<div class="cell large-6 pad40"><h2 class="title"><?php echo $columns_2_title_1; ?></h2>
				<p><?php echo $columns_2_text_1; ?></p>
			</div>    
			<div class="cell large-6 pad40"><h2 class="title"><?php echo $columns_2_title_2; ?></h2>
				<p><?php echo $columns_2_text_2; ?></p>
			</div>
		</div>
	</div>





<!-- About Us Title Intro -->

<?php
$about_us_title =  get_field('about_us_title');
$about_us_intro_text =  get_field('about_us_intro_text');
$mission_statement_title =  get_field('mission_statement_title');
$mission_statement_text =  get_field('mission_statement_text'); 
?>
    	
  
 <section id="about-us-title-intro" data-smooth-scroll>
	 <div class="grid-container pt-50">
	  <div class="grid-x">
	    <div class="cell large-7">
	    	<ul style="list-style-type:none; margin-left: 0;">
	    	<li><h1 class="title"><?php echo $about_us_title; ?></h1></li>
	    	<li><p><?php echo $about_us_intro_text; ?></p></li>
	    	</ul>
	    </div>
	    <div class="cell large-5 about-us-intro-nav">
	    	<ul style="list-style-type:none; margin-left: 0;">
	    	<li><p><a href="#about-us-title-intro">Our Mission</a></p></li>
	    	<li><p><a href="#meet-the-physicians">Meet the Physicians</a></p></li>
	    	<li><p><a href="#testimonials">Testimonials</a></p></li>
	    	<div><hr class="shortleft-blue-line"></div>
	    	</ul>
	    </div>
	  </div>
	</div>

	<div class="grid-container pt-50 pb-100">
	  <div class="grid-x">
	    <div class="cell large-12">
	    	<h2 class="title text-center"><?php echo $mission_statement_title; ?></h2>
	    	<p><?php echo $mission_statement_text; ?></p>
	    </div>
	   
	  </div>
	</div>
</section>
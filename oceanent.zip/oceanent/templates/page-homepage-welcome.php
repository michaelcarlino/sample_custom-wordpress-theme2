
<!-- Homepage Welcome -->


<?php
$welcome_headline = get_field('welcome_headline');
$welcome_subheadline = get_field('welcome_subheadline'); 
?>



<div class="grid-container ptb-100">
  <div class="grid-x">
    	
    	<div class="cell large-12 text-center"><h1 class="title"><?php echo $welcome_headline; ?></h1><p class="title-intro-lightblue"><?php echo $welcome_subheadline; ?></p>
    	</div>
   		
   		<div class="pt-25"><?php if ( have_posts() ) : while ( have_posts() ) : the_post();
				the_content();
				endwhile; else: ?>
				<?php endif; ?>
		</div>
  </div>
  </div>
</div>
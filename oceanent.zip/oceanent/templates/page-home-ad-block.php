

<!-- (Loop) Home Ad-block -->


<div class="grid-container wide">
<div class="grid-x grid-margin-x" data-equalizer>



<?php 
// the query
$the_query = new WP_Query( array( 'post_type' => 'home_ad_block', 'posts_per_page' => -1 ) ); ?>

<?php if ( $the_query->have_posts() ) : ?>

<!-- the loop -->
<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

<?php $home_ad_block_link = get_field('home_ad_block_link'); ?>

<div class="large-4 medium-4 small-12 cell">
	
	<ul style="list-style-type:none; margin-left: 0; text-align: center;">
	  	<li class="hide-for-small-only"><a href="<?php echo $home_ad_block_link; ?>"><?php the_post_thumbnail(full); ?></a></li>	
		<li><a class="button hollow homepage-adblocks" href="<?php echo $home_ad_block_link; ?>"><?php the_title(); ?></a></li>
		<!-- <li><hr class="blue-line"></li> -->
	</ul>
</div>
		





<?php endwhile; ?>
<!-- end of the loop -->

<!-- <?php wp_reset_postdata(); ?> -->

<?php else : ?>

<p><?php esc_html_e( 'Sorry no location found, please add patient education.' ); ?></p>

<?php endif; ?>
</div>
</div>




<!-- Contact Us Form -->

<?php
$contact_us_form_shortcode = get_field('contact_us_form_shortcode', 'option');
?>

    <div class="grid-container pb-100">
      <div class="grid-x">
          <div class="cell large-12 text-center">
              <a href="https://mycw36.eclinicalweb.com/portal3951/jsp/100mp/login_otp.jsp" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/img/patient-portal-icon.png"><h3 class="title-blue">Patient Portal</h3>
               <hr class="short-blue-line">
              <a href="tel:7322810100"><h3 class="title">Call today: 732.281.0100</h3></a>
        </div>
       </div>
  
    </div>
  






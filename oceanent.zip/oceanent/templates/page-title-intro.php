
<!-- Title Intro -->

<div class="grid-container ptb-100">
  <div class="grid-x">
    	<div class="cell large-12 text-center"><h1 class="title"><?php the_title(); ?></h1></div><br>
      <div class="cell large-12 text-center the_content-large"><?php if ( have_posts() ) : while ( have_posts() ) : the_post();
				the_content();
				endwhile; else: ?>
				<?php endif; ?>
	  </div>
  </div>
</div>
    	
  
 
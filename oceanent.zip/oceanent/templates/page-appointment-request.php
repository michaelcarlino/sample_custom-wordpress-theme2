

<!-- Appointment Request -->

<?php
$appointment_request_title = get_field('appointment_request_title', 'option');
$appointment_request_sub_title = get_field('appointment_request_sub_title', 'option'); 
$appointment_request_text = get_field('appointment_request_text', 'option');
$appointment_request_form_shortcode = get_field('appointment_request_form_shortcode', 'option');
?>

<div id="appointment-request-form" class="grid-container full appointment-request-background ptb-150">
  <div class="grid-x">
  	<div class="grid-container">
  	<div class="grid-x">	
    <div class="cell large-6">
    	<div class="grid-x">
    	<div class="cell large-12"><h1 class="appointment-request-title", ""><?php echo $appointment_request_title; ?></h1></div><br>
      <div class="cell large-12"><h4 class="appointment-request-sub-title"><?php echo $appointment_request_sub_title; ?></h4></div>
    	<div class="cell large-12"><p class="appointment-request-text"><?php echo $appointment_request_text; ?></p></div>
    </div>
    </div>
    <div class="cell large-6"><?php echo $appointment_request_form_shortcode; ?></div>
   </div>
  </div>
 </div>
</div>



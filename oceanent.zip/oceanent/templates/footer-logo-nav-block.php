
<!-- Footer Logo, Nav, Phone, Social Block -->
					
					<div class="grid-container">
					  <div class="grid-x">
					    
					    <div class="cell large-4"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="" src="<?php the_field('logo_footer', 'option'); ?>" alt="OceanENT" /></a></div>
					    
					    <div class="cell large-4 show-for-large-only"><nav class="" role="navigation">
			    						<?php joints_footer_links(); ?>
			    					</nav></div>
					    
					    <div class="cell large-4"><h3 style="display:inline-block;" class="title-white">Call today:</h3>&nbsp;<h3 style="display:inline-block;"class="title-light-blue"><a href="tel:7322810100">732.281.0100</a></h3></br><h6 style="display:inline-block;"class="title-upper-light-blue">Follow Us:</h6>&nbsp;<?php 
									 $image = get_field('facebook_icon', 'option');
									  if (!empty($image)) {
									    $url = get_field('facebook_url', 'option');
									    ?>
									      <a href="<?php echo $url; ?>" target="_blank"><img src="<?php 
									          echo $image['url']; ?>" alt="facebook" /></a>
									    <?php 
									  }
									?>&nbsp;
									<?php 
									 $image = get_field('twitter_icon', 'option');
									  if (!empty($image)) {
									    $url = get_field('twitter_url', 'option');
									    ?>
									      <a href="<?php echo $url; ?>" target="_blank"><img src="<?php 
									          echo $image['url']; ?>" alt="facebook" /></a>
									    <?php 
									  }
									?></div>
					  </div>
					</div>
					<hr class="lightblue-line">
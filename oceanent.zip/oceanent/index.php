<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 */

get_header(); ?>
		<!-- Page Breadcrumbs -->
		<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>
			
	<div class="grid-container ptb-100">
	  <div class="grid-x">
		
		    <div class="cell large-7">
		    
			   <?php /*?> <?php if (have_posts()) : while (have_posts()) : the_post(); ?><?php */?>
				<?php
$args = array(
   // 'posts_per_page'         => '1',
	'cat'				=> '-38',
	
	'post_status' => 'publish',
	'orderby'				=> 'date',
	'order'					=> 'DESC',
	
);
$query = new WP_Query( $args );
if ( $query->have_posts() ) : ?>
    <?php while ( $query->have_posts() ) : $query->the_post(); ?>
			 
					<!-- To see additional archive styles, visit the /parts directory -->
					<?php get_template_part( 'parts/loop', 'archive' ); ?>
				    
				<?php endwhile; ?>	

					<?php joints_page_navi(); ?>
					
				<?php else : ?>
											
					<?php get_template_part( 'parts/content', 'missing' ); ?>
						
				<?php endif; ?>
																								
		    </div> 

		    <div style="padding-left:75px;" class="cell large-5">
		    <p><?php get_sidebar(); ?></p>
			</div>

		</div> 
	</div> 

<?php get_footer(); ?>
<?php
/*
Template Name: Services
*/

get_header(); ?>

<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>

<!-- Title Inro -->
<?php get_template_part( 'templates/page', 'title-intro' ); ?>

<!-- Services -->
<div class="pb-150">
<?php get_template_part( 'parts/loop', 'services' ); ?>
</div>

<?php get_footer(); ?>

<?php 
/**
 * (Patient Education) - Template Layout for Displaying Post
 */

get_header(); ?>

<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>
			
<div class="content">

	<div>
		
		<main>
		
		    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
		    	<?php get_template_part( 'parts/loop', 'single-patient-education' ); ?>
		    	
		    <?php endwhile; else : ?>
		
		   		<?php get_template_part( 'parts/content', 'missing' ); ?>

		    <?php endif; ?>

		</main> <!-- end #main -->

	</div> <!-- end #inner-content -->

<?php get_template_part( 'parts/loop', 'patient-education-post-block' ); ?>

<!-- Appointment Request -->
<?php get_template_part( 'templates/page', 'appointment-request' ); ?>

</div> <!-- end #content -->

<?php get_footer(); ?>
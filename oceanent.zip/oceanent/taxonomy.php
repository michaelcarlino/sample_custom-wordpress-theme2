<?php
/**
 * Displays archive pages if a speicifc template is not set. 
 *
 * For more info: https://developer.wordpress.org/themes/basics/template-hierarchy/
 */

get_header(); ?>
		<!-- Page Breadcrumbs -->
		<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>
			
	<div class="grid-container pt-100">
	  <div class="grid-x">
	  		<?php get_template_part( 'parts/taxonomy', 'term-name' ); ?>
		
		    <main class="cell large-12 ptb-50" role="main">
			    
		    			
		    	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			 
					<!-- To see additional archive styles, visit the /parts directory -->


					<?php get_template_part( 'parts/loop', 'taxonomy' ); ?>
				    
				<?php endwhile; ?>	

					<div class="text-right"><?php joints_page_navi(); ?></div>
					
				<?php else : ?>
											
					<?php get_template_part( 'parts/content', 'missing' ); ?>
						
				<?php endif; ?>
		
			</main> <!-- end #main -->
	
	    
	    </div> 
	    
	</div> 
<?php get_footer(); ?>
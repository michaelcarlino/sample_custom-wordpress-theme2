<?php 
/**
 * The template for displaying search results pages
 *
 * For more info: https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 */
 	
get_header(); ?>
<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>
			
	<div class="content">

		<div class="grid-container ptb-100">
	
			<main class="main small-12 medium-12 large-12 cell" role="main">
				<header>
					<h1 class="title text-center"><?php _e( 'Search Results for:', 'jointswp' ); ?>&nbsp;<?php echo esc_attr(get_search_query()); ?>
					</h1>
				</header>

				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			 
					<!-- To see additional archive styles, visit the /parts directory -->
					<?php get_template_part( 'parts/loop', 'archive-search' ); ?>
				    
				<?php endwhile; ?>	

					<div class="text-right"><?php joints_page_navi(); ?></div>
					
				<?php else : ?>
				
					<?php get_template_part( 'parts/content', 'missing' ); ?>
						
			    <?php endif; ?>
	
		    </main> <!-- end #main -->
		
		
		
		</div> <!-- end #inner-content -->

	</div> <!-- end #content -->

<?php get_footer(); ?>

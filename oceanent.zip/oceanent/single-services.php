<?php 
/**
 * (Services) - Template Layout for Displaying Post
 */

get_header(); ?>

<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>
			
<div class="content">

	<div>
		
		<main>
		
		    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
		    	<?php get_template_part( 'parts/loop', 'single-services' ); ?>
		    	
		    <?php endwhile; else : ?>
		
		   		<?php get_template_part( 'parts/content', 'missing' ); ?>

		    <?php endif; ?>

		</main> <!-- end #main -->

	</div> <!-- end #inner-content -->

	<?php if ( is_single( 'ent-services' ) ) : ?>
<?php get_template_part( 'parts/loop', 'services-post-block' ); ?>
<?php endif ;?>
	
</div> <!-- end #content -->

<?php get_footer(); ?>
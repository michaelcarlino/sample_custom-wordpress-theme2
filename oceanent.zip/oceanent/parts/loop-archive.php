<?php
/**
 * Template part for displaying posts
 *
 * Used for single, index, archive, search.
 */
?>
	<div class="grid-container ptb-50">
	  <div class="grid-x">
	    <div class="cell large-12"><h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
		<?php get_template_part( 'parts/content', 'news-byline' ); ?>			
	    </div>
	    <section class="featured-image" itemprop="text">
					<?php the_post_thumbnail('full'); ?>
				</section>
 		<!-- <div class="cell large-12 ptb-50"><p><?php echo get_the_excerpt();?></p></div>
	  </div> -->
	  <div class="cell large-12"><p><?php echo get_the_excerpt();?></p></div>
	  </div>
	</div>
			
	<footer>
		<?php wp_link_pages( array( 'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'jointswp' ), 'after'  => '</div>' ) ); ?>
		<p class="tags"><?php the_tags('<span class="tags-title">' . __( 'Tags:', 'jointswp' ) . '</span> ', ', ', ''); ?></p>	
	</footer> 
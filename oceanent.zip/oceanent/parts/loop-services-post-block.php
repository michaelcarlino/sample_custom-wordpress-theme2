
<!-- (Loop) Services Post Block -->

<!-- <div class="grid-container">
	<div class="grid-x">
		<div class="large-12 text-center"><p class="title-intro-lightblue">Select a Topic Below to Learn More</p></div>
	</div>
</div> -->

<div class="grid-container pb-50">
<div class="grid-x grid-margin-x" data-equalizer>
<?php 

// the query
$the_query = new WP_Query( array( 'post_type' => 'services_post_block', 'posts_per_page' => -1) ); ?>

<?php if ( $the_query->have_posts() ) : ?>

<!-- the loop -->
<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
 
<?php
$services_post_image = get_field('services_post_image');
$services_post_services = get_field('services_post_services');
?>



<div class="large-4 medium-4 small-12 cell pb-50">
	<div>
		<img style="padding-right:15px;" src="<?php echo $services_post_image; ?>">
  	</div>

	<ul style="list-style-type:none; margin-left: 0; text-align: left;">
	  <li><h2 class="title pt-25"><?php the_title(); ?></h2></li>
	  <li><p><?php echo $services_post_services; ?></p></li>
	</ul>	
</div>



<?php endwhile; ?>
<!-- end of the loop -->

<!-- <?php wp_reset_postdata(); ?> -->

<?php else : ?>

<p><?php esc_html_e( 'Sorry no services found, please add a service.' ); ?></p>

<?php endif; ?>
</div>
</div>
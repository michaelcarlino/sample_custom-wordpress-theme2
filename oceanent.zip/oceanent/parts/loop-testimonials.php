
<!-- (Loop) Testimonials -->

        
      


        <section id="testimonials" class="testimonials-background" id="testimonials">
          <div class="grid-container pt-100">
            <div class="grid-x">
              <div class="cell large-12 text-center"><h1 class="title">Testimonials</h1></div>
            </div>
          </div>

            <div class="orbit" role="region" aria-label="doctors" data-orbit data-options="animInFromLeft:fade-in; animInFromRight:fade-in; animOutToLeft:fade-out; animOutToRight:fade-out; autoPlay:true; infiniteWrap:true; pauseOnHover: false; ">
              <ul class="orbit-container">
                <div class="orbit-controls">
                  <button class="orbit-previous"><img src="<?php echo get_template_directory_uri(); ?>/img/arrow-left.png" ></button>
                  <button class="orbit-next show"><img src="<?php echo get_template_directory_uri(); ?>/img/arrow-right.png" ></button>
                </div>


                <?php
                $args1 = array(
                'posts_per_page' => 1,
                //'category' => 'add category here',
                );
                $the_query = new WP_Query( array( 'post_type' => 'testimonials', 'posts_per_page' => -1 ) ); ?>
                <?php if ( $the_query->have_posts() ) : ?>
                <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

                  <li class="orbit-slide is-active">
                        <div class="grid-container">
                          <div class="grid-x">
                            <div class="cell large-12 text-center testimonials-spacing text-center">
                              <p class="testimonials"><?php echo get_the_content();?></p>
                                <p><?php the_title(); ?></p>
                            </div>
                          </div>
                        </div>
                  </li>

                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
                <?php else : ?>
                    <p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
                <?php endif; ?>

              </ul>
              <!-- <nav class="orbit-bullets">
                <button class="is-active" data-slide="0"><span class="show-for-sr">First slide details.</span><span class="show-for-sr">Current Slide</span></button>
                <button data-slide="1"><span class="show-for-sr">Second slide details.</span></button>
                <button data-slide="2"><span class="show-for-sr">Third slide details.</span></button>
                <button data-slide="3"><span class="show-for-sr">Fourth slide details.</span></button>
              </nav> -->
            </div>
  
        </section>






















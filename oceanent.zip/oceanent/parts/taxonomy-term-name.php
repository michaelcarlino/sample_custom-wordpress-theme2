

<!-- Displays Taxonomy Term Name -->


<div class="grid-container">
	<div class="grid-x">
	<div class="cell large-12 text-center"><h1 class="title"><?php
	  	$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) ); echo $term->name; // shows custom taxonomy name?></h1>
		<div class="the_content-large"<p><?php
		echo term_description($term_id, "resource"); ?></p></div>
		
	</div>
	</div>
</div>
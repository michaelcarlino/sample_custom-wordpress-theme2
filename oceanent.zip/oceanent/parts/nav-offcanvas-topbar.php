<?php
/**
 * The off-canvas menu uses the Off-Canvas Component
 *
 * For more info: http://jointswp.com/docs/off-canvas-menu/
 */
?>

<div class="top-bar show-for-large hide-for-small" id="top-bar-menu">
	<div class="top-bar-left float-left">
		<div class="grid-container header-spacer">
			<div class="grid-x">
				
				<div class="cell large-2">
					<ul class="menu">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="logo-header" src="<?php the_field('logo_header', 'option'); ?>" alt="OceanENT" /></a>
					</ul>
				</div>

				<div class="cell large-10">
					<div class="top-bar-right float-right">
						<!-- The Main Menu -->
						<?php joints_top_nav(); ?>	
					</div>									
				</div>
			</div>
		</div>
	</div>
</div>
	

<div class="top-bar show-for-small-only" id="top-bar-menu">
	<div class="top-bar-left float-left">
		<div class="grid-container header-spacer">
			<div class="grid-x">
				
				<div class="cell small-4">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="logo-header" src="<?php the_field('logo_header', 'option'); ?>" alt="OceanENT" /></a>
				</div>

				<div class="cell small-8">
					<a class="float-right" style="margin-top:12px;" data-toggle="off-canvas"><?php _e( '<button class="menu-icon" type="button" data-toggle></button>', 'jointswp' ); ?></a>								
				</div>
			</div>
		</div>
	</div>
</div>

<div class="top-bar hide-for-large-only show-for-medium-only" id="top-bar-menu">
	<div class="top-bar-left float-left">
		<div class="grid-container header-spacer">
			<div class="grid-x">
				
				<div class="cell small-4">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="logo-header" src="<?php the_field('logo_header', 'option'); ?>" alt="OceanENT" /></a>
				</div>

				<div class="cell small-8">
					<a class="float-right" style="margin-top:12px;" data-toggle="off-canvas"><?php _e( '<button class="menu-icon" type="button" data-toggle></button>', 'jointswp' ); ?></a>								
				</div>
			</div>
		</div>
	</div>
</div>
	




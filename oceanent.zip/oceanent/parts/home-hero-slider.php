
<!-- Home Hero Slider -->

<?php
$home_hero_slide_1 = get_field('home_hero_slide_1', 'option');
$home_hero_slide_2 = get_field('home_hero_slide_2', 'option'); 
$home_hero_slide_3 = get_field('home_hero_slide_3', 'option');
$home_hero_slide_4 = get_field('home_hero_slide_4', 'option');
?>


  <div class="orbit" role="region" aria-label="OceanENT" data-orbit data-options="animInFromLeft:fade-in; animInFromRight:fade-in; animOutToLeft:fade-out; animOutToRight:fade-out; autoPlay:true; infiniteWrap:true; pauseOnHover: false; " data-use-m-u-i="true">
  <div class="orbit-wrapper">
    <div class="orbit-controls">
      <button class="orbit-previous"><img src="<?php echo get_template_directory_uri(); ?>/img/arrow-left.png" ></button>
      <button class="orbit-next show"><img src="<?php echo get_template_directory_uri(); ?>/img/arrow-right.png" ></button>
    </div>

    <!------------ Logo Overlay ------------>
    <div class="logo-overlay"><img src="<?php echo get_template_directory_uri(); ?>/img/oceanent-overlay.png" /></div>
    <!-------------------------------------->
    
    <ul class="orbit-container">
      <li class="is-active orbit-slide">
        <figure class="orbit-figure">
      

	<img class="orbit-full" src="<?php echo $home_hero_slide_1; ?>" />


        <!-- <figcaption class="orbit-caption">OceanENT</figcaption> -->
        </figure>
      </li>
      <li class="orbit-slide">
        <figure class="orbit-figure">
        

	<img class="orbit-full" src="<?php echo $home_hero_slide_2; ?>" />


        <!-- <figcaption class="orbit-caption">OceanENT</figcaption> -->
        </figure>
      </li>
      <li class="orbit-slide">
        <figure class="orbit-figure">
       

	<img class="orbit-full" src="<?php echo $home_hero_slide_3; ?>" />


          <!-- <figcaption class="orbit-caption">OceanENT</figcaption> -->
        </figure>
      </li>
      <li class="orbit-slide">
        <figure class="orbit-figure">
         

	<img class="orbit-full" src="<?php echo $home_hero_slide_4; ?>" />


          <!-- <figcaption class="orbit-caption">OceanENT</figcaption> -->
        </figure>
      </li>
    </ul>
  </div>
</div>


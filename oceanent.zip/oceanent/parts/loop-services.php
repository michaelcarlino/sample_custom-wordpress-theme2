

<!-- (Loop) Services -->

<?php
   
// Custom Post Query
$args = array( 'post_type' => 'services', 'posts_per_page' );
$loop = new WP_Query( $args );

// Odd/ Even
$counter = 0;//Set up a counter	
				if (have_posts()) : while ($loop->have_posts()) : $loop->the_post(); $counter++;   ?>

<?php
//We are in loop so we can check if counter is odd or even
if( $counter % 2 == 0 ) : //It's even?> 

<div class="grid-container full">
<div class="grid-x align-middle">
	 	<div class="cell small-12 medium-12 large-6 large-order-2 medium-order-1 small-order-1">
   	<?php echo get_the_post_thumbnail(get_the_ID(), array(900,900)); ?>
</div>
   	 <div class="cell small-12 medium-12 large-6 large-order-1 medium-order-2 small-order-2 pad100"><h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_the_excerpt();?></p>
   	 </div>
  
  </div> 	       		
</div>


<?php else : //It's Odd?>
<div class="grid-container full">
<div class="grid-x align-middle">
	 <div class="cell small-12 medium-12 large-6 large-order-1 medium-order-1 small-order-1">
   	<?php echo get_the_post_thumbnail(get_the_ID(), array(900,900)); ?>
</div>

   	 <div class="cell small-12 medium-12 large-6 large-order-2 medium-order-2 small-order-2 pad100"><h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2><p><?php echo get_the_excerpt();?></p>
   	 </div>

   	 
  
  </div> 	       		
</div>



<?php endif; ?>

<?php endwhile;?>

<?php endif; ?>



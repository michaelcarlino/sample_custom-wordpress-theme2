<?php
/**
 * (News) Template Part for Displaying a Single Post
 */

$hero_image_url = '';
    if (has_post_thumbnail()):
      $hero_image_url = get_the_post_thumbnail_url(null, 'large');
    endif;
    if (!empty($hero_image_url)):
?>
    

	<div class="grid-container full">
	  <div class="grid-x">
	    <div class="cell large-12 hero-image" style='display: flex; background-image:url(<?php echo $hero_image_url; ?>);'>
	    </div><?php endif; ?>
	  </div>
	</div>

	<?php

	$news_article_credits = get_field('news_article_credits');
	$read_full_news_article = get_field('read_full_news_article'); 

	?>

	<div class="grid-container ptb-100">
	  <div class="grid-x">
	    <div class="cell large-12 text-center pb-50"><h1 class="title" ><?php the_title(); ?></h1></div>
	    <div class="cell large-12 pb-25"><p class="article-credit">Source:&nbsp;<?php echo $news_article_credits; ?></p></div>
 		<div class="cell large-12"><?php the_content(); ?></div>

 		<!-- <div class="cell large-12 text-center"><a href="<?php echo home_url(); ?>/news/">Back to News Articles</a></div>
 		<div class="cell large-12"><hr class="short-blue-line"></div> -->
	  </div>
		
	</div>
			
	<footer>
		<?php wp_link_pages( array( 'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'jointswp' ), 'after'  => '</div>' ) ); ?>
		<p class="tags"><?php the_tags('<span class="tags-title">' . __( 'Tags:', 'jointswp' ) . '</span> ', ', ', ''); ?></p>	
	</footer> 
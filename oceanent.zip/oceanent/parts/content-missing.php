<?php
/**
 * The template part for displaying a message that posts cannot be found
 */
?>

<div class="grid-container">
  <div class="grid-x grid-margin-x">
    <div class="cell large-12 text-center"><br><h3 class="title"><strong><u>NOT FOUND</u></strong> try your search again.</h3></div>

    <div class="cell large-12">
    <form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
				    <div>
				        <input type="text" value="" name="s" id="s" />
				        <input type="submit" class="search-submit button" id="searchsubmit" value="Search" />
				    </div>
				</form>
			</div>
  </div>
</div>

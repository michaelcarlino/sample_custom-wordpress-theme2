
<!-- (Loop) Patient Resources Post Block -->


<div class="grid-container">
<div class="grid-x grid-margin-x" data-equalizer>
<?php 

// the query
$the_query = new WP_Query( array( 'post_type' => 'patient_resources', 'posts_per_page' => -1, ) ); ?>

<?php if ( $the_query->have_posts() ) : ?>

<!-- the loop -->
<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

<?php
$patient_resources_learn_more_link = get_field('patient_resources_learn_more_link');
?>
 
<div class="large-4 medium-4 small-12 cell">
	<ul style="list-style-type:none; margin-left: 0; text-align: left;">
	  <li><h2 class="title"><?php the_title(); ?></h2></li>
	  <li><p><?php the_content(); ?></p></li>
	  <li><a href="<?php echo $patient_resources_learn_more_link; ?>" target="_blank"><h5 class="title">Learn More</h5></a></li>
	  <li><hr class="shortleft-blue-line"></li>
	</ul>	
</div>



<?php endwhile; ?>
<!-- end of the loop -->

<!-- <?php wp_reset_postdata(); ?> -->

<?php else : ?>

<p><?php esc_html_e( 'Sorry no location found, please add a location.' ); ?></p>

<?php endif; ?>
</div>
</div>
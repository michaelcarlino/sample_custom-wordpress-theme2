<?php
/**
 * The Topbar Menu
 */
?>

<div class="grid-container full topbar-nav">
	<div class="grid-container">
		<div class="grid-x">
		  <div class="cell large-6"><a class="topbar-phone" href="tel:<?php the_field('topbar_phone_text', 'option'); ?>"><?php the_field('topbar_phone_text', 'option'); ?></a></div>

		  <div class="cell large-6">
		  	<ul class="topbar-nav hide-for-small-only float-right">
		  		<li class="topbar-nav"><?php joints_topbar_nav(); ?></li>
		  		
		  		<!-- Search Modal Popup Trigger -->
		  		<li class="topbar-nav"><a href="#" data-open="search-modal"><img src="<?php echo get_template_directory_uri(); ?>/img/search-icon.png" ></a></li>
		  		  	
		  		<!-- Search Modal Popup Box -->
		  		<div style="padding:40px;" class="reveal" id="search-modal" data-reveal>
				  <form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
				    <div><label class="screen-reader-text" for="s"><p>Search for:</p></label>
				        <input type="text" value="" name="s" id="s" />
				        <input type="submit" class="search-submit button" id="searchsubmit" value="Search" />
				    </div>
				</form>
				  <button class="close-button" data-close aria-label="Close modal" type="button">
				    <span aria-hidden="true">&times;</span>
				  </button>
				</div>

		  		<!-- Select Language - temporary placeholder -->
		  		<li class="topbar-nav"><a href=""><!-- <img src="<?php echo get_template_directory_uri(); ?>/img/select-language.png" > --></a></li>
		  						<li class="topbar-nav float-right">
		  			
									<?php 
									 $image = get_field('twitter_icon', 'option');
									  if (!empty($image)) {
									    $url = get_field('twitter_url', 'option');
									    ?>
									      <a href="<?php echo $url; ?>" target="_blank"><img src="<?php 
									          echo $image['url']; ?>" alt="facebook" /></a>
									    <?php 
									  }
									?>
		  						</li>
		  						<li class="topbar-nav float-right">
		  							<?php 
									 $image = get_field('facebook_icon', 'option');
									  if (!empty($image)) {
									    $url = get_field('facebook_url', 'option');
									    ?>
									      <a href="<?php echo $url; ?>" target="_blank"><img src="<?php 
									          echo $image['url']; ?>" alt="facebook" /></a>
									    <?php 
									  }
									?>
		  						</li>
		  						
		  		
		  	</ul></div>
		  
		</div>
	</div>
</div>


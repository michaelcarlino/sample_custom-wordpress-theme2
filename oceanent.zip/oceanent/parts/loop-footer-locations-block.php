
<!-- (Loop) Footer Location Block -->

<!-- Back to Top -->
<a href="#0" class="cd-top">Top</a>
<!-- --------------- -->


<div class="grid-container">
<div class="grid-x">
<?php 

// the query
$the_query = new WP_Query( array( 'post_type' => 'locations', 'posts_per_page' => -1) ); ?>

<?php if ( $the_query->have_posts() ) : ?>

<!-- the loop -->
<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
 
<?php
$location_city =  get_field('location_city');
$location_state =  get_field('location_state');
$location_zip =  get_field('location_zip');
$location_address =  get_field('location_address');
$location_get_directions =  get_field('location_get_directions'); 
?>


<div class="large-4 cell">
	
	  <div class="text-left">
	    <a href="<?php echo $location_get_directions; ?>" target="_blank"><p class="footer-locations-block"><span><?php echo $location_city; ?></span><br><?php echo $location_address; ?><br><?php echo $location_city; ?>,&nbsp;<?php echo $location_state; ?>&nbsp;<?php echo $location_zip; ?></p></a>
	  </div>

</div>


<?php endwhile; ?>
<!-- end of the loop -->

<!-- <?php wp_reset_postdata(); ?> -->

<?php else : ?>
<p><?php esc_html_e( 'Sorry no location found, please add a location.' ); ?></p>
<?php endif; ?>
</div>
</div>
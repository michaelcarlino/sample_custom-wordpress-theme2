<?php
/**
 * The template part for displaying offcanvas content
 *
 * For more info: http://jointswp.com/docs/off-canvas-menu/
 */
?>





<div class="off-canvas position-right" id="off-canvas" data-off-canvas>
	

	<div class="grid-container">
	  	<div class="grid-x pt-25">
		    <div class="cell small-6"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img class="logo-header" src="<?php the_field('logo_header', 'option'); ?>" alt="OceanENT" /></a>
		    </div>
		    <div class="cell small-6"></div>
		</div>

	    <div class="grid-x">
	    <div class="cell small-12"><?php joints_off_canvas_nav(); ?> <!-- show menu --></div>
		</div>

		<div class="grid-x">
		    <div class="cell small-11"><form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
				    <div><!-- <label class="screen-reader-text" for="s"><p>Search for:</p></label> -->
				        <input type="text" placeholder="Enter your search" value="" name="s" id="s" />
				        <input type="submit" class="search-submit button" id="searchsubmit" value="Search" />
				    </div>
				</form>
			</div>
		</div>

		<div class="grid-x">
		    <div class="cell small-6"><a href="tel:<?php the_field('topbar_phone_text', 'option'); ?>"><h5 class="title"><?php the_field('topbar_phone_text', 'option'); ?></h5></a></div>
		    <div class="cell small-3"><?php 
									 $image = get_field('twitter_icon_mobile', 'option');
									  if (!empty($image)) {
									    $url = get_field('twitter_url', 'option');
									    ?>
									      <a href="<?php echo $url; ?>" target="_blank"><img src="<?php 
									          echo $image['url']; ?>" alt="facebook" /></a>
									    <?php 
									  }
									?></div>
		    <div class="cell small-3"><?php 
									 $image = get_field('facebook_icon_mobile', 'option');
									  if (!empty($image)) {
									    $url = get_field('facebook_url', 'option');
									    ?>
									      <a href="<?php echo $url; ?>" target="_blank"><img src="<?php 
									          echo $image['url']; ?>" alt="facebook" /></a>
									    <?php 
									  }
									?></div>
		  </div>
	</div>



	<!-- show widget -->
	<?php if ( is_active_sidebar( 'offcanvas' ) ) : ?>

		<?php dynamic_sidebar( 'offcanvas' ); ?>

	<?php endif; ?>

</div>
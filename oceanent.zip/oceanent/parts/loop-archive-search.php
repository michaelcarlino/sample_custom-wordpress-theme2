<?php
/**
 * Template part for displaying posts
 *
 * Used for single, index, archive, search.
 */
?>
	<div class="grid-container">
	  <div class="grid-x">
	    <div class="cell large-12 pt-50"><h2 class="title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
				
	    </div>
	    
 		<div class="cell large-12"><p><?php echo get_the_excerpt();?></p></div>
	  </div>
	</div>
			
	
<?php
/**
 * (News) Template Part for Displaying a Single Post
 */


?>
   	<div class="grid-container ptb-100">
	  <div class="grid-x">
	    <div class="cell large-12 text-center pb-50"><h1 class="title" ><?php the_title(); ?></h1></div>
	    <!-- <div class="cell large-12 pb-25"><p class="article-credit">Source:&nbsp;<?php echo $news_article_credits; ?></p></div> -->
 		<div class="cell large-12"><?php the_content(); ?></div>

 		<!-- <div class="cell large-12 text-center"><a href="<?php echo home_url(); ?>/news/">Back to News Articles</a></div>
 		<div class="cell large-12"><hr class="short-blue-line"></div> -->
	  </div>
		<!-- <div class="text-right"><a href="<?php echo $read_full_news_article; ?>" target="_blank"><h5 class="title">Read full news article</h5></a></div> -->
	</div>
			
	<footer>
		<?php wp_link_pages( array( 'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'jointswp' ), 'after'  => '</div>' ) ); ?>
		<p class="tags"><?php the_tags('<span class="tags-title">' . __( 'Tags:', 'jointswp' ) . '</span> ', ', ', ''); ?></p>	
	</footer> 
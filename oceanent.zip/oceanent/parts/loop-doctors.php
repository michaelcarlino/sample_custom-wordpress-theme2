
<!-- (Loop) Doctors Homepage -->


        <section class="ptb-50">

            <div class="orbit" role="region" aria-label="doctors" data-orbit data-options="animInFromLeft:fade-in; animInFromRight:fade-in; animOutToLeft:fade-out; animOutToRight:fade-out; autoPlay:true; infiniteWrap:true; pauseOnHover: false; ">
              <ul class="orbit-container">
                <div class="orbit-controls">
                  <button class="doctors orbit-previous">&#9664;&#xFE0E;</button>
                  <button class="doctors orbit-next show">&#9654;&#xFE0E;</button>
                </div>


                <?php
                $args1 = array(
                'posts_per_page' => 1,
                //'category' => 'add category here',
                );
                $the_query = new WP_Query( array( 'post_type' => 'doctors', 'posts_per_page' => -1 ) ); ?>
                <?php if ( $the_query->have_posts() ) : ?>
                <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

                  <li class="orbit-slide is-active">
                    <!-- <?php the_post_thumbnail('slider', array('class' => 'orbit-image')); ?> -->
                    <?php
                        $hero_image_url = '';
                            if (has_post_thumbnail()):
                              $hero_image_url = get_the_post_thumbnail_url(null, 'large');
                            endif;
                            if (!empty($hero_image_url)):
                        ?>

                        <div class="grid-container wide">
                          <div class="grid-x">
                            <div class="cell large-6 hero-image" style='display: flex; background-position: top; background-image:url(<?php echo $hero_image_url; ?>);'>
                                </div><?php endif; ?>
                            <div style="padding:10%;" class="cell large-6">
                                
                                    <h3 class="title-blue"><?php the_title(); ?></h3>
                                    <p><?php echo get_the_content();?></p>
                                    <a href="/dev-oceanent/about-us/#<?php the_ID();?>">Read More</a>
                                    <div class="pt-15"><hr class="shortleft-blue-line"></div>
                                    
                                
                            </div>
                          </div>
                        </div>
                    <!-- <figcaption class="orbit-caption"><?php the_title(); ?></figcaption> -->
                  </li>

                <?php endwhile; ?>
                <?php wp_reset_postdata(); ?>
                <?php else : ?>
                    <p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
                <?php endif; ?>

              </ul>
              <!-- <nav class="orbit-bullets">
                <button class="is-active" data-slide="0"><span class="show-for-sr">First slide details.</span><span class="show-for-sr">Current Slide</span></button>
                <button data-slide="1"><span class="show-for-sr">Second slide details.</span></button>
                <button data-slide="2"><span class="show-for-sr">Third slide details.</span></button>
                <button data-slide="3"><span class="show-for-sr">Fourth slide details.</span></button>
              </nav> -->
            </div>
  
        </section>






















<?php
/**
 * Template part for Taxonomy posts
 * This page lists all the Education Link and when clicked will goto page with the article on it.
 */

?>



	<div class="grid-container">
	  <div class="grid-x">

	    <div class="cell large-12"><p><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><h2 class="title"><?php the_title(); ?></h2></a></p>		
	    	<?php the_excerpt();?><br>
	    </div> 		
	  </div>
	</div>




			
	
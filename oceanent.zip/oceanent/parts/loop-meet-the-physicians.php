
<!-- ************************************** -->
<!-- Meet the Physicians (Outside the LOOP) -->
<!-- ************************************** -->

<?php
$meet_the_physicians_intro_title =  get_field('meet_the_physicians_intro_title');
$meet_the_physicians_intro_text =  get_field('meet_the_physicians_intro_text'); 
?>
    	
 <section id="meet-the-physicians">
 	<div class="grid-container full meet-the-physicians-background">
 	 <div class="grid-x">
	 <div class="grid-container ptb-100">
	  <div class="grid-x">
	    <div class="cell large-12">
	    	<ul style="list-style-type:none; margin-left: 0;">
	    	<li><h1 class="text-center meet-the-physicians-title"><?php echo $meet_the_physicians_intro_title; ?></h1></li>
	    	<li><p class="text-center large-white-text"><?php echo $meet_the_physicians_intro_text; ?></p></li>
	    	</ul>
	    </div>
	  </div>
	</div>
  </div>
</div>
</section>


<!-- ****************************** -->
<!-- (Loop) for Meet the Physicians -->
<!-- ****************************** -->
<section>
<?php
   
// Custom Post Query
$args = array( 'post_type' => 'doctors', 'posts_per_page' );
$loop = new WP_Query( $args );

// Odd/ Even
$counter = 0;//Set up a counter	
				if (have_posts()) : while ($loop->have_posts()) : $loop->the_post(); $counter++;   ?>

<?php

// Custom fields for section
$doctors_main_text =  get_field('doctors_main_text'); 

//We are in loop so we can check if counter is odd or even
if( $counter % 2 == 0 ) : //It's even?> 
<div class="doctor-container"  id="<?php the_ID();?>">
<div class="grid-container full">
<div class="grid-x align-middle">
	 	<div class="cell small-12 medium-12 large-6 large-order-2 medium-order-1 small-order-1">
   	<?php echo get_the_post_thumbnail(get_the_ID(), array(900,900)); ?>
</div>
   	 <div class="cell small-12 medium-12 large-6 large-order-1 medium-order-2 small-order-2 pad100"><h2 class="title"><?php the_title(); ?></h2><p><?php echo get_the_content();?></p>
   	 </div>
  
  </div> 	       		
</div>

<!-- Doctor Main Text -->
<div class="grid-container ptb-150">
<div class="grid-x align-middle">
   	 <div class="cell small-12 medium-12 large-12">
   	 	<p><?php echo $doctors_main_text; ?></p>
   	 </div>
  
  </div>
</div>
</div><!--End Container-->

<?php else : //It's Odd?>
  <div class="doctor-container"  id="<?php the_ID();?>">
<div class="grid-container full">
<div class="grid-x align-middle">
	 <div class="cell small-12 medium-12 large-6 large-order-1 medium-order-1 small-order-1">
   	<?php echo get_the_post_thumbnail(get_the_ID(), array(900,900)); ?>
</div>

   	 <div class="cell small-12 medium-12 large-6 large-order-2 medium-order-2 small-order-2 pad100"><h2 class="title"><?php the_title(); ?></h2><p><?php echo get_the_content();?></p>
   	 </div>  
  </div> 	       		
</div>

<!-- Doctor Main Text -->
<div class="grid-container ptb-150">
<div class="grid-x align-middle">
   	 <div class="cell small-12 medium-12 large-12">
   	 	<p><?php echo $doctors_main_text; ?></p>
   	 </div>
  
  </div>
</div>
</div><!--END CONTAINER-->



<?php endif; ?>

<?php endwhile;?>

<?php endif; ?>
</section>




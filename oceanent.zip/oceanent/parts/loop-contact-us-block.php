
<!-- (Loop) Contact Us Block -->


<div class="grid-container wide">
<div class="grid-x grid-margin-x" data-equalizer>
<?php 

// the query
$the_query = new WP_Query( array( 'post_type' => 'locations', 'posts_per_page' => -1 ) ); ?>

<?php if ( $the_query->have_posts() ) : ?>

<!-- the loop -->
<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
 
<?php
$location_building_image = get_field('location_building_image');
$location_google_map = get_field('location_google_map'); 
$location_city =  get_field('location_city');
$location_state =  get_field('location_state');
$location_zip =  get_field('location_zip');
$location_address =  get_field('location_address');
$location_office_hours =  get_field('location_office_hours');
$location_get_directions =  get_field('location_get_directions');
?>


<div class="large-4 medium-4 small-12 cell">
	<div>
		<?php echo $location_google_map; ?>
  	</div>

	<ul style="list-style-type:none; margin-left: 0; text-align: center;">
	  <li><h2 class="title pt-25"><?php echo $location_city; ?>,&nbsp;<?php echo $location_state; ?></h2></li>
	  <li><p><?php echo $location_address; ?><br><?php echo $location_city; ?>,&nbsp;<?php echo $location_state; ?>&nbsp;<?php echo $location_zip; ?></p></li>
	  <li><hr class="blue-line"></li>
	  <li><h5 class="title">Office Hours</h5></li>
	  <li><p><?php echo $location_office_hours; ?></p></li>
	  <li><a href="<?php echo $location_get_directions; ?>" target="_blank"><h5 class="title">Get Directions</h5></a></li>
	</ul>	
</div>



<?php endwhile; ?>
<!-- end of the loop -->

<!-- <?php wp_reset_postdata(); ?> -->

<?php else : ?>

<p><?php esc_html_e( 'Sorry no location found, please add a location.' ); ?></p>

<?php endif; ?>
</div>
</div>
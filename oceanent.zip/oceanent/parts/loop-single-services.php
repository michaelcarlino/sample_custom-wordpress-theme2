
<?php
/**
 * (Services) Template Part for Displaying a Single Post
 */

$hero_image_url = '';
    if (has_post_thumbnail()):
      $hero_image_url = get_the_post_thumbnail_url(null, 'large');
    endif;
    if (!empty($hero_image_url)):

?>


	<div class="grid-container full">
	  <div class="grid-x">
	    <div class="cell large-12 hero-image" style='display: flex; background-image:url(<?php echo $hero_image_url; ?>);'>
	    </div><?php endif; ?>
	  </div>
	</div>

	<div class="grid-container ptb-100">
	  <div class="grid-x">
	    <div class="cell large-12 text-center"><h1 class="title" ><?php the_title(); ?></h1></div>
 		<div class="cell large-12 text-center the_content-large"><?php the_content(); ?></div>
	  </div>
	</div>


			
	<footer>
		<?php wp_link_pages( array( 'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'jointswp' ), 'after'  => '</div>' ) ); ?>
		<p class="tags"><?php the_tags('<span class="tags-title">' . __( 'Tags:', 'jointswp' ) . '</span> ', ', ', ''); ?></p>	
	</footer>
						
		
			

									

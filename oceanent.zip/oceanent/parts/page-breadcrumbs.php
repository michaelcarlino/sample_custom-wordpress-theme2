<?php
/**
 * Page Breadcrumbs
 */
?>

<div class="grid-container full breadcrumbs">
	<div class="grid-container">
		<div class="grid-x">
			<div class="cell large-12">
				<!-- Page Breadcrumbs --><?php if ( function_exists('yoast_breadcrumb') ) {yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );}?></div>    
		</div>
	</div>
</div>



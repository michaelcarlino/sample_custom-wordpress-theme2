
<!-- (Loop) Patient Education Block -->


<div class="grid-container wide ptb-100">
<div class="grid-x grid-margin-x" data-equalizer>



<?php 
// the query
$the_query = new WP_Query( array( 'post_type' => 'patient_education', 'posts_per_page' => -1 ) ); ?>

<?php if ( $the_query->have_posts() ) : ?>

<!-- the loop -->
<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>


<div class="large-3 medium-6 small-12 cell">
	
	<ul style="list-style-type:none; margin-left: 0; text-align: center;">
	  	<li><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_post_thumbnail(full); ?></a></li>	
		<li><a class="button hollow patient-education" href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
		<!-- <li><hr class="blue-line"></li> -->
	</ul>
</div>
		





<?php endwhile; ?>
<!-- end of the loop -->

<!-- <?php wp_reset_postdata(); ?> -->

<?php else : ?>

<p><?php esc_html_e( 'Sorry no location found, please add patient education.' ); ?></p>

<?php endif; ?>
</div>
</div>
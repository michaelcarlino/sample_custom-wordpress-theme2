
<!-- (Loop) Education Links Block -->


<div class="grid-container wide ptb-50">
<div class="grid-x grid-margin-x" data-equalizer>


<?php
//$path = get_template_directory_uri() .'/img/';
		$getArgs = array(
		'parent' => 0,
		'order' => 'DESC',
		'orderby' => 'count',
   		'hide_empty' => false,
		);
$terms = get_terms( 'resource', $getArgs );


foreach ( $terms as $term ) {
	$category_image = get_field('category_image', $term);
	$url = $category_image['url'];
	$size = 'large';
    $thumb = $category_image['sizes'][ $size ];
	$term_link = get_term_link( $terms, 'resource' );

	echo '<div class="cell large-4 medium-6 small-12 text-center">';
    echo '<div>';
    // echo '<img src="' . $thumb . '" alt="" />';
    echo '<h3 class="edu-block-title"><a href="' . esc_url( get_term_link( $term ) ) . '" >'.'<img src="' . $thumb . '" alt="" />' . $term->name . ' </a></h3>';
    echo '<hr class="edu-block-blue-line">';
    echo ' </div>';
	echo ' </div>';

}

?>
</div>
</div>


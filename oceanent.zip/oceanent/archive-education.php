<?php
/*
Template Name: Patient Education
*/

get_header(); ?>

<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>

<!-- Title Intro -->

<div class="grid-container pt-50">
  <div class="grid-x">
    	<div class="cell large-12 text-center"><h1 class="title">Patient Education</h1></div><br>
      <div class="cell large-12 text-center the_content-large"><p>Please explore our library of topics to stay well-informed on ENT disorders and diseases.</p>
	  </div>
  </div>	
</div>
    	



<!-- Search Function -->
<div class="grid-container">
  <div class="grid-x">
    <div class="cell large-12">
    	<form role="search" method="get" id="searchform" action="<?php echo home_url( '/' ); ?>">
    <div><label class="screen-reader-text" for="s"></label>
        <input type="text" value="" name="s" id="s" />
        <input class="button" type="submit" id="searchsubmit" value="Search" />
    </div>
</form>
    </div>
  </div>
</div>


<!-- Patient Education Block -->
<div >
<?php get_template_part( 'parts/loop', 'patient-education-post-block' ); ?>
</div>


<div class="grid-container">
  <div class="grid-x">
    <div id="education-links" class="cell large-12 text-center">
    	<h1 class="title">Education Links</h1>
    </div>
  </div>
</div>

<!-- Patient Education Links Block -->
<div>
<?php get_template_part( 'parts/loop', 'education-links' ); ?>
</div>


<?php get_footer(); ?>

<?php
/*
Template Name: Our Locations
*/

get_header(); ?>

<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>

<!-- Title Inro -->
<?php get_template_part( 'templates/page', 'title-intro' ); ?>

<!-- Our Locations -->
<?php get_template_part( 'parts/loop', 'our-locations-block' ); ?>

<!-- Appointment Request -->
<?php get_template_part( 'templates/page', 'appointment-request' ); ?>

<!-- Columns 2 -->
<?php get_template_part( 'templates/page', 'columns-2' ); ?>


<?php get_footer(); ?>

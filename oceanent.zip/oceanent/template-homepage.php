<?php
/*
Template Name: Homepage
*/

get_header(); ?>

<!-- Home Hero Slider -->
<?php get_template_part( 'parts/home', 'hero-slider' ); ?>

<!-- Home Ad Blocks -->
<div class="pt-50">
<?php get_template_part( 'templates/page', 'home-ad-block' ); ?>

<!-- Title Inro -->
<?php get_template_part( 'templates/page', 'homepage-welcome' ); ?>

<!-- Doctors -->
<?php get_template_part( 'parts/loop', 'doctors' ); ?>

<!-- Appointment Request -->
<?php get_template_part( 'templates/page', 'appointment-request' ); ?>	


<?php get_footer(); ?>

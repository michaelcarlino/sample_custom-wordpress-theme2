<?php
/**
 * The Footer template is for displaying the footer. 
 *
 * Comtains closing divs for header.php.
 *
 * 
 */			
 ?>
		<!-- footer -->	
				<footer class="footer" role="contentinfo">
					<!-- template part (footer locations block) -->
					<?php get_template_part( 'templates/footer', 'top-links' ); ?>

					<!-- template part (footer locations block) -->
					<?php get_template_part( 'templates/footer', 'logo-nav-block' ); ?>

					<!-- template part (footer locations block) -->
					<?php get_template_part( 'parts/loop', 'footer-locations-block' ); ?>
				</footer> <!-- end .footer -->
			
			</div>  <!-- end .off-canvas-content -->
					
		</div> <!-- end .off-canvas-wrapper -->
		
		<?php wp_footer(); ?>
		
	</body>
	
</html> <!-- end page -->
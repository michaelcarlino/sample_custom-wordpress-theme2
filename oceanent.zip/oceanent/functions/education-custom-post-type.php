<?php
/* joints Custom Post Type Example
This page walks you through creating 
a custom post type and taxonomies. You
can edit this one or copy the following code 
to create another one. 

I put this in a separate file so as to 
keep it organized. I find it easier to edit
and change things if they are concentrated
in their own file.

*/


// let's create the function for the custom type
function cpt_education() { 
	// creating (registering) the custom type 
	register_post_type( 'education', /* (http://codex.wordpress.org/Function_Reference/register_post_type) */
	 	// let's now add all the options for this post type
		array('labels' => array(
			'name' => __('Education', 'jointswp'), /* This is the Title of the Group */
			'singular_name' => __('Education', 'jointswp'), /* This is the individual type */
			'all_items' => __('All Educations', 'jointswp'), /* the all items menu item */
			'add_new' => __('Add New', 'jointswp'), /* The add new menu item */
			'add_new_item' => __('Add New Education', 'jointswp'), /* Add New Display Title */
			'edit' => __( 'Edit', 'jointswp' ), /* Edit Dialog */
			'edit_item' => __('Edit Educations', 'jointswp'), /* Edit Display Title */
			'new_item' => __('New Education', 'jointswp'), /* New Display Title */
			'view_item' => __('View Education', 'jointswp'), /* View Display Title */
			'search_items' => __('Search Education', 'jointswp'), /* Search Custom Type Title */ 
			'not_found' =>  __('Nothing found in the Database.', 'jointswp'), /* This displays if there are no entries yet */ 
			'not_found_in_trash' => __('Nothing found in Trash', 'jointswp'), /* This displays if there is nothing in the trash */
			'parent_item_colon' => ''
			), /* end of arrays */
			'description' => __( 'Please explore our extensive library covering the full array of topics associated with the areas of plastic surgery we specialize in. We encourage you to look through these pages whenever you have an interest or concern about changing your appearance.', 'jointswp' ), /* Custom Type Description */
			'public' => true,
			'publicly_queryable' => true,
			'exclude_from_search' => false,
			'show_ui' => true,
			'query_var' => true,
			//'cptp_permalink_structure' => '/%resource_type%/%postname%/',  
			'menu_position' => 8, /* this is what order you want it to appear in on the left hand side menu */ 
			'menu_icon' => 'dashicons-book', /* the icon for the custom post type menu. uses built-in dashicons (CSS class name) */
			'rewrite'	=> array( 'slug' => 'education/%resource%', 'with_front' => false ), /* you can specify its url slug */
			'has_archive' => 'education', /* you can rename the slug here */
			'capability_type' => 'post',
			'hierarchical' => true,
			/* the next one is important, it tells what's enabled in the post editor */
			'supports' => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'trackbacks', 'custom-fields', 'comments', 'revisions', 'sticky')
	 	) /* end of options */
	); /* end of register post type */
	
	/* this adds your post categories to your custom post type */
	//register_taxonomy_for_object_type('category', 'resources_post_type');
	/* this adds your post tags to your custom post type */
	//register_taxonomy_for_object_type('post_tag', 'resources_post_type');
	
	//flush_rewrite_rules();		
} 

	// adding the function to the Wordpress init
	add_action( 'init', 'cpt_education');
	
	/*
	for more information on taxonomies, go here:
	http://codex.wordpress.org/Function_Reference/register_taxonomy
	*/
	
	// now let's add custom categories (these act like categories)
    register_taxonomy( 'resource', 
    	array('education'), /* if you change the name of register_post_type( 'custom_type', then you have to change this */
    	array('hierarchical' => true,     /* if this is true, it acts like categories */ 
			  'has_archive'	=> true,
			  'parent' => 0,
    		'labels' => array(
    			'name' => __( 'Resource', 'jointswp' ), /* name of the custom taxonomy */
    			'singular_name' => __( 'Resource', 'jointswp' ), /* single taxonomy name */
    			'search_items' =>  __( 'Search Resource Categories', 'jointswp' ), /* search title for taxomony */
    			'all_items' => __( 'All Resource Categories', 'jointswp' ), /* all title for taxonomies */
    			'parent_item' => __( 'Parent Resource Category', 'jointswp' ), /* parent title for taxonomy */
    			'parent_item_colon' => __( 'Parent Resource Category:', 'jointswp' ), /* parent taxonomy title */
    			'edit_item' => __( 'Edit Resource Category', 'jointswp' ), /* edit custom taxonomy title */
    			'update_item' => __( 'Update Resource Category', 'jointswp' ), /* update title for taxonomy */
    			'add_new_item' => __( 'Add New Resource Category', 'jointswp' ), /* add new title for taxonomy */
    			'new_item_name' => __( 'New Resource Category Name', 'jointswp' ) /* name title for taxonomy */
    		),
    		'show_admin_column' => true, 
    		'show_ui' => true,
    		'query_var' => true,
			//'cptp_permalink_structure' => '/%resource_type%/', 
    		'rewrite'	=> array( 'slug' => 'education', 'with_front' =>false),
    	)
    );   



    //THIS FUNCTION WORKS  - ONE LEVEL
//function wpse_5308_post_type_link( $link, $post ) {
//    if ( $post->post_type === 'resources_post_type' ) {
//        if ( $terms = get_the_terms( $post->ID, 'resource_type' ) )
//            $link = str_replace( '%resource_type%', current( $terms )->slug, $link );
//    }
//
//    return $link;
//}
//
//add_filter( 'post_type_link', 'wpse_5308_post_type_link', 10, 2 );



function resource_post_link( $permalink, $post_id, $leavename ) {
    if ( strpos( $permalink, '%resource%' ) === false ) {
        return $permalink;
    }

    // Get post
    $post = get_post($post_id);
    if ( ! $post ) {
        return $permalink;
    }

    // Get taxonomy terms
    $terms = wp_get_object_terms($post->ID, 'resource');   
    if ( ! is_wp_error( $terms ) && ! empty( $terms ) && is_object( $terms[0] ) ) {
        $taxonomy_slug = $terms[0]->slug;
    } else { 
        $taxonomy_slug = 'uncategorized'; 
    }

    return str_replace( '%resource%', $taxonomy_slug, $permalink );
}   
// add_filter( 'post_link', 'wpse239701_events_post_link', 10, 3 ); // Not needed - we aren't adding our custom taxonomy to posts, but if we were, this would be used.
add_filter( 'post_type_link', 'resource_post_link', 10, 3 );






//KEEP - MULTIPLE LEVELS - STILL RESEARCH - HOW TO CHECK IF LAST URI SEGMENT IS A CUSTOM POST TYPE OR TAXONOMY TERM
//function wpd_gallery_request_filter( $request ){
//    if( array_key_exists( 'resource_type' , $request )
//        && ! get_term_by( 'slug', $request['resource_type'], 'resource_type' ) ){
//            $request['resources_post_type'] = $request['resource_type'];
//            $request['name'] = $request['resource_type'];
//            $request['post_type'] = 'resources_post_type';
//            unset( $request['resource_type'] );
//    }
//    return $request;
//}
//add_filter( 'request', 'wpd_gallery_request_filter' );


<?php
/*
Template Name: Patient Resources
*/

get_header(); ?>

<!-- Page Breadcrumbs -->
<?php get_template_part( 'parts/page', 'breadcrumbs' ); ?>

<!-- Title Inro -->
<?php get_template_part( 'templates/page', 'title-intro' ); ?>

<!-- Patient Resources -->
<div class="pb-100">
<?php get_template_part( 'parts/loop', 'patient-resources-post-block' ); ?>
</div>

<?php get_footer(); ?>
